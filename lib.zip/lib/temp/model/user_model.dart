class User{
  String id;
  String name;

  User({required this.id,required this.name});
}