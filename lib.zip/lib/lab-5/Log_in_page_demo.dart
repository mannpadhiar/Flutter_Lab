import 'package:flutter/material.dart';

class LogInPageDemo extends StatelessWidget {
  const LogInPageDemo({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('LOGIN PAGE'),),
      body: Center(child: Text('Hello Login Page')),
    );
  }
}
