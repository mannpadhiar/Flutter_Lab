import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import 'package:sem_5/lab-5/temp_example.dart';
import 'package:sem_5/profile/view/profile_home_page.dart';
import 'package:sem_5/profile/view/profile_view.dart';
import 'package:sem_5/temp.dart';
import 'package:sem_5/tempppp/controller.dart';
import 'package:sem_5/tempppp/view.dart';
import 'package:sem_5/views/log_in_view.dart';
import 'E-commerce/views/e_commerce_view.dart';
import 'lab-10/user_local_databse_view.dart';
import 'lab-11/user_api_view.dart';
import 'lab-14/custom_package_example.dart';
import 'lab-15/camera_permission.dart';
import 'lab-15/multiple_permission.dart';
import 'lab-16/file_example.dart';
import 'lab-3/views/crud_person_view.dart';
import 'lab-4/alert_ dialog_example.dart';
import 'lab-5/Log_in_page_demo.dart';
import 'lab-5/login_middleware.dart';
import 'lab-5/navigation_example_named.dart';
import 'lab-6/RxBoolExample.dart';
import 'lab-6/non_reactive.dart';
import 'lab-6/text_field_ractive.dart';
import 'lab-6/time_print.dart';
import 'lab-7/RxListExample.dart';
import 'lab-7/list_controller.dart';
import 'lab-8/snackBarException.dart';
import 'map/google_location.dart';

void main() {
  Get.put(ListController());
  Get.put(StudentDatabaseController());
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      darkTheme: ThemeData.dark(),
      title: 'Flutter Demo',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
      ),
      home: FileExample(),
      // getPages: [
      //   GetPage(name: '/', page: () => NavigationExample(),),
      //   GetPage(name: '/login', page: () => LogInPageDemo(),),
      //   GetPage(name: '/tempExample', page: () => TempExample(),middlewares: [LoginMiddleware()]),
      // ],
      // initialRoute: '/',
    );
  }
}

