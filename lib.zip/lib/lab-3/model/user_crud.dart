class Person{
  String name;

  Person({
    required this.name,
  });
}
