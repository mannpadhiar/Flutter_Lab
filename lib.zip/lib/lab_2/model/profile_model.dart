class UserModel{
  final String name;
  final String address;
  final int number;
  final String email;

  UserModel(this.name, this.address, this.number, this.email);
}