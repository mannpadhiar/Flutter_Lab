class User{
  String? name;
  String? email;
  String? number;

  User({
    this.name,
    this.email,
    this.number,
  });
}