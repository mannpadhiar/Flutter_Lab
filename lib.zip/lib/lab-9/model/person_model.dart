class Student{
  String name;

  Student({
    required this.name,
  });
}
